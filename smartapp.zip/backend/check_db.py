import sqlite3

DB_PATH = r'C:\Users\IPS\.gemini\antigravity\scratch\smartlife-controller\backend\smartlife.db'

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
c = conn.cursor()

print("=== TOTAL REGISTROS POR DISPOSITIVO ===")
c.execute("SELECT device_name, COUNT(*) as total FROM energy_log GROUP BY device_id")
for row in c.fetchall():
    print(f"  {row['device_name']}: {row['total']} registros")

print("\n=== ULTIMOS 10 REGISTROS (todos los dispositivos) ===")
c.execute("SELECT id, device_name, timestamp FROM energy_log ORDER BY id DESC LIMIT 10")
for row in c.fetchall():
    print(f"  ID={row['id']}  {row['timestamp']}  {row['device_name']}")

print("\n=== REGISTROS DUPLICADOS (mismo device_id y timestamp) ===")
c.execute("""
    SELECT device_id, device_name, timestamp, COUNT(*) as cnt
    FROM energy_log
    GROUP BY device_id, timestamp
    HAVING cnt > 1
    ORDER BY timestamp DESC
    LIMIT 10
""")
rows = c.fetchall()
if rows:
    for row in rows:
        print(f"  DUPLICADO: {row['device_name']} @ {row['timestamp']} — {row['cnt']} veces")
else:
    print("  No se encontraron duplicados exactos en la base de datos.")

conn.close()
