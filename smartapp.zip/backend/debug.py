import os
import json
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv()
ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
API_ENDPOINT = os.getenv("TUYA_ENDPOINT", "https://openapi.tuyaus.com")

openapi = TuyaOpenAPI(API_ENDPOINT, ACCESS_ID, ACCESS_KEY)
openapi.connect()

print("=== TEST ENDPOINT: /v1.0/users/devices (All linked devices) ===")
# Tuya endpoint to get all devices from linked app accounts:
response = openapi.get("/v1.0/iot-01/associated-users/devices")
print(json.dumps(response, indent=2))
