import os
import json
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv(dotenv_path=r'C:\Users\IPS\.gemini\antigravity\scratch\smartlife-controller\backend\.env')

ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
API_ENDPOINT = os.getenv("TUYA_ENDPOINT", "https://openapi.tuyaus.com")
DEVICE_ID = os.getenv("TUYA_DEVICE_ID", "")

openapi = TuyaOpenAPI(API_ENDPOINT, ACCESS_ID, ACCESS_KEY)
openapi.connect()

results = {}

r1 = openapi.get(f"/v1.0/iot-03/devices/{DEVICE_ID}")
results["iot-03"] = r1

r2 = openapi.get(f"/v1.0/devices/{DEVICE_ID}")
results["v1.0"] = r2

r3 = openapi.get(f"/v1.0/devices/{DEVICE_ID}/status")
results["status"] = r3

with open('output.txt', 'w') as f:
    json.dump(results, f, indent=4)
