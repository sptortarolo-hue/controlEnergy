@echo off
echo ==========================================
echo   Smart Life Home Energy - Iniciando...
echo ==========================================
echo.
echo 1. Verificando dependencias...
pip install -r requirements.txt waitress --quiet

echo 2. Iniciando servidor Backend (Flask)...
echo Acceso local: http://localhost:5001
echo Acceso Red:   http://[TU-IP-LOCAL]:5001
echo.
echo Presiona Ctrl+C para cerrar el servidor.
echo.

python -c "from waitress import serve; from app import app; print('Servidor en marcha...'); serve(app, host='0.0.0.0', port=5001)"

pause
