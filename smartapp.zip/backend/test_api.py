import os
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv(dotenv_path=r'C:\Users\IPS\.gemini\antigravity\scratch\smartlife-controller\backend\.env')

ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
API_ENDPOINT = os.getenv("TUYA_ENDPOINT", "https://openapi.tuyaus.com")
DEVICE_ID = os.getenv("TUYA_DEVICE_ID", "")

print(f"Endpoint: {API_ENDPOINT}")
print(f"Device ID: {DEVICE_ID}")

openapi = TuyaOpenAPI(API_ENDPOINT, ACCESS_ID, ACCESS_KEY)
openapi.connect()

print("Fetching device...")
response = openapi.get(f"/v1.0/iot-03/devices/{DEVICE_ID}")
print("Response:", response)
