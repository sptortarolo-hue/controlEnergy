import os
import json
from tuya_connector import TuyaOpenAPI

ACCESS_ID = "su8dwvkfp5t5r5rcwsfe"
ACCESS_KEY = "22f612152a1b403b8d27390907657718"
DEVICE_ID = "az1763213062950hXUXA"

ENDPOINTS = [
    "https://openapi.tuyaus.com",
    "https://openapi-ueaz.tuyaus.com",
    "https://openapi.tuyaeu.com",
    "https://openapi-weaz.tuyaeu.com",
    "https://openapi.tuyacn.com",
    "https://openapi.tuyain.com",
]

results = {}

for ep in ENDPOINTS:
    try:
        openapi = TuyaOpenAPI(ep, ACCESS_ID, ACCESS_KEY)
        openapi.connect()
        # Just getting token is enough to know if client is valid for this DC
        response = openapi.get(f"/v1.0/devices/{DEVICE_ID}")
        results[ep] = response
    except Exception as e:
        results[ep] = str(e)

with open('dc_results.json', 'w') as f:
    json.dump(results, f, indent=4)
