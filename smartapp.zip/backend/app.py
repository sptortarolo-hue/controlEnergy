import os
import sqlite3
import threading
import time
import base64
import struct
from datetime import datetime
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv()

app = Flask(__name__, static_folder="../frontend", static_url_path="")
CORS(app)

# ==========================================
# STATIC FILE ROUTES (Serving Frontend)
# ==========================================
@app.route('/')
def serve_index():
    return app.send_static_file('index.html')

@app.route('/dashboard.html')
def serve_dashboard():
    return app.send_static_file('dashboard.html')

ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
API_ENDPOINT = os.getenv("TUYA_ENDPOINT", "https://openapi.tuyaus.com")

DB_PATH = os.path.join(os.path.dirname(__file__), "smartlife.db")

# ==========================================
# Init OpenAPI
# ==========================================
print("\n=== STARTING BACKEND ===")
print(f"Loaded Access ID: {ACCESS_ID}")
print(f"Loaded Endpoint:  {API_ENDPOINT}")
print("========================\n")

openapi = TuyaOpenAPI(API_ENDPOINT, ACCESS_ID, ACCESS_KEY)
openapi.connect()

# ==========================================
# DATABASE SETUP
# ==========================================
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS energy_log (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id     TEXT NOT NULL,
            device_name   TEXT,
            timestamp     TEXT NOT NULL,
            voltage       REAL,
            current_a     REAL,
            power_w       REAL,
            power_factor  REAL,
            energy_kwh    REAL,
            temperature   REAL,
            switch_state  INTEGER
        )
    """)
    conn.commit()
    conn.close()

init_db()

# ==========================================
# PHASE_A DECODER
# ==========================================
def decode_phase_a(b64_str):
    """
    Decodes Tuya phase_a Base64 string into electrical measurements.
    Byte layout (big-endian):
      [0-1]  Voltage (V × 10)
      [2-3]  Current (mA)
      [4]    Power Factor (%)
      [5-7]  Active Power (W)
    """
    try:
        raw = base64.b64decode(b64_str)
        if len(raw) < 8:
            return {}
        voltage     = struct.unpack('>H', raw[0:2])[0] / 10.0
        current_ma  = struct.unpack('>H', raw[2:4])[0]
        power_factor= raw[4]
        power_w     = struct.unpack('>I', b'\x00' + raw[5:8])[0]
        return {
            "voltage": voltage,
            "current_a": current_ma / 1000.0,
            "power_factor": power_factor,
            "power_w": power_w
        }
    except Exception as e:
        print(f"[decode_phase_a] Error: {e}")
        return {}

# ==========================================
# FETCH + PARSE DEVICES FROM TUYA
# ==========================================
def fetch_devices_from_tuya():
    response = openapi.get("/v1.0/iot-01/associated-users/devices")
    if not response.get("success"):
        return []
    return response.get("result", {}).get("devices", [])

def parse_device_metrics(device):
    """Extract all electrical metrics from a device's status list."""
    status_map = {s['code']: s['value'] for s in device.get('status', [])}
    metrics = {}

    phase = decode_phase_a(status_map.get('phase_a', ''))
    metrics.update(phase)

    if 'total_forward_energy' in status_map:
        metrics['energy_kwh'] = status_map['total_forward_energy'] / 100.0
    if 'temp_current' in status_map:
        metrics['temperature'] = status_map['temp_current']
    if 'switch' in status_map:
        metrics['switch_state'] = 1 if status_map['switch'] else 0
    elif 'switch_1' in status_map:
        metrics['switch_state'] = 1 if status_map['switch_1'] else 0

    return metrics

# ==========================================
# HOURLY SNAPSHOT (saved to DB)
# ==========================================
def save_snapshot():
    devices = fetch_devices_from_tuya()
    if not devices:
        print("[Snapshot] No devices found.")
        return

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    ts = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

    for device in devices:
        m = parse_device_metrics(device)
        c.execute("""
            INSERT INTO energy_log
                (device_id, device_name, timestamp, voltage, current_a,
                 power_w, power_factor, energy_kwh, temperature, switch_state)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            device['id'],
            device.get('name', ''),
            ts,
            m.get('voltage'),
            m.get('current_a'),
            m.get('power_w'),
            m.get('power_factor'),
            m.get('energy_kwh'),
            m.get('temperature'),
            m.get('switch_state')
        ))

    conn.commit()
    conn.close()
    print(f"[Snapshot] Saved at {ts}")

# ==========================================
# BACKGROUND POLLING THREAD (every hour)
# Only runs in the main process, NOT in Flask's reloader child process
# ==========================================
def polling_loop():
    # Wait 10s before first run so Flask is ready
    time.sleep(10)
    while True:
        try:
            save_snapshot()
        except Exception as e:
            print(f"[Polling] Error: {e}")
        time.sleep(3600)  # 1 hour

import os
# Werkzeug's reloader sets WERKZEUG_RUN_MAIN=true in the child process.
# We only want to start the background thread in the PARENT/main process.
if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
    polling_thread = threading.Thread(target=polling_loop, daemon=True)
    polling_thread.start()
    print("[Polling] Background thread started (main process).")
else:
    print("[Polling] Skipped in reloader child process.")

# ==========================================
# API ROUTES
# ==========================================

@app.route('/api/status', methods=['GET'])
def status():
    if not ACCESS_ID or not ACCESS_KEY:
        return jsonify({"status": "error", "message": "Credenciales faltantes en .env"}), 400
    return jsonify({"status": "ok", "message": "Conectado a la Nube de Tuya"})


@app.route('/api/devices', methods=['GET'])
def get_devices():
    try:
        devices = fetch_devices_from_tuya()
        # Enrich each device with decoded phase_a metrics
        for device in devices:
            device['_metrics'] = parse_device_metrics(device)
        return jsonify({"status": "success", "devices": devices})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/devices/<device_id>/commands', methods=['POST'])
def send_command(device_id):
    data = request.json
    commands = data.get("commands", [])
    response = openapi.post(f"/v1.0/devices/{device_id}/commands", {"commands": commands})
    if response.get("success"):
        return jsonify({"status": "success", "result": response.get("result")})
    else:
        return jsonify({"status": "error", "message": response.get("msg")}), 400


@app.route('/api/history/snapshot', methods=['POST'])
def manual_snapshot():
    """Trigger a manual data snapshot."""
    try:
        save_snapshot()
        return jsonify({"status": "success", "message": "Snapshot guardado."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/history/hourly', methods=['GET'])
def get_hourly():
    """
    Returns hourly readings for a device.
    Query params: device_id, days (default 1)
    """
    device_id = request.args.get('device_id', '')
    days = int(request.args.get('days', 1))
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("""
        SELECT timestamp, voltage, current_a, power_w, power_factor,
               energy_kwh, temperature, switch_state
        FROM energy_log
        WHERE device_id = ?
          AND timestamp >= datetime('now', ?)
        ORDER BY timestamp ASC
    """, (device_id, f'-{days} days'))
    rows = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify({"status": "success", "data": rows})


@app.route('/api/history/daily', methods=['GET'])
def get_daily():
    """
    Returns daily energy consumption (kWh delta) for a device.
    Query params: device_id, days (default 7)
    """
    device_id = request.args.get('device_id', '')
    days = int(request.args.get('days', 7))
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    # Get the first and last reading per day, then calculate delta
    c.execute("""
        SELECT
            date(timestamp) AS day,
            MIN(energy_kwh) AS kwh_start,
            MAX(energy_kwh) AS kwh_end,
            MAX(power_w)    AS peak_power,
            AVG(voltage)    AS avg_voltage,
            AVG(current_a)  AS avg_current
        FROM energy_log
        WHERE device_id = ?
          AND timestamp >= datetime('now', ?)
          AND energy_kwh IS NOT NULL
        GROUP BY date(timestamp)
        ORDER BY day ASC
    """, (device_id, f'-{days} days'))
    rows = []
    for row in c.fetchall():
        d = dict(row)
        start = d.pop('kwh_start') or 0
        end   = d.pop('kwh_end')   or 0
        d['energy_consumed_kwh'] = round(max(0, end - start), 3)
        rows.append(d)
    conn.close()
    return jsonify({"status": "success", "data": rows})


@app.route('/api/history/devices', methods=['GET'])
def get_logged_devices():
    """Returns all devices that have logged data."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT DISTINCT device_id, device_name FROM energy_log ORDER BY device_name")
    rows = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify({"status": "success", "devices": rows})


@app.route('/api/history/stats', methods=['GET'])
def get_stats():
    """
    Returns aggregated statistics for a device within a date range.
    Query params: device_id, date_from (YYYY-MM-DD), date_to (YYYY-MM-DD)
    """
    device_id = request.args.get('device_id', '')
    date_from = request.args.get('date_from', '')  # e.g. 2026-05-01
    date_to   = request.args.get('date_to', '')    # e.g. 2026-05-10

    if not device_id or not date_from or not date_to:
        return jsonify({"status": "error", "message": "Faltan parámetros: device_id, date_from, date_to"}), 400

    # Include the full end day (up to 23:59:59)
    date_to_full = f"{date_to} 23:59:59"
    date_from_full = f"{date_from} 00:00:00"

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # --- Global stats for the period ---
    c.execute("""
        SELECT
            COUNT(*)            AS total_readings,
            MIN(energy_kwh)     AS kwh_start,
            MAX(energy_kwh)     AS kwh_end,
            AVG(power_w)        AS avg_power,
            MAX(power_w)        AS peak_power,
            AVG(voltage)        AS avg_voltage,
            AVG(current_a)      AS avg_current,
            AVG(power_factor)   AS avg_pf,
            AVG(temperature)    AS avg_temp
        FROM energy_log
        WHERE device_id = ?
          AND timestamp BETWEEN ? AND ?
          AND energy_kwh IS NOT NULL
    """, (device_id, date_from_full, date_to_full))
    global_row = dict(c.fetchone())

    energy_consumed = round(max(0, (global_row['kwh_end'] or 0) - (global_row['kwh_start'] or 0)), 3)

    # --- Hourly breakdown: average power per hour-of-day (0-23) ---
    c.execute("""
        SELECT
            CAST(strftime('%H', timestamp) AS INTEGER) AS hour,
            AVG(power_w)   AS avg_power,
            MAX(power_w)   AS peak_power,
            COUNT(*)       AS readings
        FROM energy_log
        WHERE device_id = ?
          AND timestamp BETWEEN ? AND ?
          AND power_w IS NOT NULL
        GROUP BY hour
        ORDER BY hour ASC
    """, (device_id, date_from_full, date_to_full))
    hourly_rows = [dict(r) for r in c.fetchall()]

    # --- Daily breakdown: energy consumed per day ---
    c.execute("""
        SELECT
            date(timestamp)     AS day,
            MIN(energy_kwh)     AS kwh_start,
            MAX(energy_kwh)     AS kwh_end,
            AVG(power_w)        AS avg_power,
            MAX(power_w)        AS peak_power
        FROM energy_log
        WHERE device_id = ?
          AND timestamp BETWEEN ? AND ?
          AND energy_kwh IS NOT NULL
        GROUP BY date(timestamp)
        ORDER BY day ASC
    """, (device_id, date_from_full, date_to_full))
    daily_rows = []
    for row in c.fetchall():
        d = dict(row)
        consumed = round(max(0, (d.pop('kwh_end') or 0) - (d.pop('kwh_start') or 0)), 3)
        d['energy_consumed_kwh'] = consumed
        daily_rows.append(d)

    conn.close()

    # Find peak hour (hour with highest avg power)
    peak_hour = None
    if hourly_rows:
        peak_hour_row = max(hourly_rows, key=lambda x: x['avg_power'] or 0)
        peak_hour = peak_hour_row['hour']

    return jsonify({
        "status": "success",
        "period": {"from": date_from, "to": date_to},
        "summary": {
            "total_readings":    global_row['total_readings'],
            "energy_consumed_kwh": energy_consumed,
            "avg_power_w":       round(global_row['avg_power'] or 0, 1),
            "peak_power_w":      global_row['peak_power'],
            "avg_voltage":       round(global_row['avg_voltage'] or 0, 1),
            "avg_current":       round(global_row['avg_current'] or 0, 3),
            "avg_pf":            round(global_row['avg_pf'] or 0, 1),
            "avg_temp":          round(global_row['avg_temp'] or 0, 1),
            "peak_hour":         peak_hour,
        },
        "hourly": hourly_rows,
        "daily":  daily_rows,
    })


@app.route('/api/debug', methods=['GET'])
def debug_tuya():
    response = openapi.get("/v1.0/iot-01/associated-users/devices")
    return jsonify({"endpoint_used": API_ENDPOINT, "raw_response": response})


if __name__ == '__main__':
    # Using host='0.0.0.0' allows access from other devices in the same network (like your phone)
    app.run(host='0.0.0.0', port=5001, debug=True)
