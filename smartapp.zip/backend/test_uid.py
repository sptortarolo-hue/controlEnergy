import os
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv(dotenv_path=r'C:\Users\IPS\.gemini\antigravity\scratch\smartlife-controller\backend\.env')

ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
API_ENDPOINT = os.getenv("TUYA_ENDPOINT", "https://openapi.tuyaus.com")

openapi = TuyaOpenAPI(API_ENDPOINT, ACCESS_ID, ACCESS_KEY)
openapi.connect()

print("Fetching users linked to the project...")
response = openapi.get("/v1.0/iot-03/users")
print("Users Response:", response)

if response.get("success") and response.get("result", {}).get("list"):
    uid = response["result"]["list"][0]["uid"]
    print(f"\nFound UID: {uid}")
    
    print("Fetching devices for this UID...")
    dev_response = openapi.get(f"/v1.0/users/{uid}/devices")
    print("Devices Response:", dev_response)
else:
    print("\nNo users found or error occurred.")
