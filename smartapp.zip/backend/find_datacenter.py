import os
from dotenv import load_dotenv
from tuya_connector import TuyaOpenAPI

load_dotenv(dotenv_path=r'C:\Users\IPS\.gemini\antigravity\scratch\smartlife-controller\backend\.env')

ACCESS_ID = os.getenv("TUYA_ACCESS_ID", "")
ACCESS_KEY = os.getenv("TUYA_ACCESS_SECRET", "")
DEVICE_ID = os.getenv("TUYA_DEVICE_ID", "")

ENDPOINTS = [
    "https://openapi.tuyaus.com",      # Western America
    "https://openapi-ueaz.tuyaus.com", # Eastern America
    "https://openapi.tuyaeu.com",      # Central Europe
    "https://openapi-weaz.tuyaeu.com", # Western Europe
    "https://openapi.tuyacn.com",      # China
    "https://openapi.tuyain.com",      # India
]

print("Testing all Tuya data centers to find your device...\n")

found = False
for endpoint in ENDPOINTS:
    try:
        openapi = TuyaOpenAPI(endpoint, ACCESS_ID, ACCESS_KEY)
        openapi.connect()
        response = openapi.get(f"/v1.0/iot-03/devices/{DEVICE_ID}")
        
        if response.get("success"):
            print(f"SUCCESS! Your device is located in this data center: {endpoint}")
            print(f"Device Name: {response['result']['name']}")
            print(f"\nPlease update your .env file to use:\nTUYA_ENDPOINT={endpoint}")
            found = True
            break
        else:
            print(f"[X] {endpoint} -> Failed: {response.get('msg')}")
    except Exception as e:
        print(f"[X] {endpoint} -> Error: {str(e)}")

if not found:
    print("\nCOULD NOT FIND THE DEVICE IN ANY DATA CENTER.")
    print("This means either:")
    print("1. You have not linked your Smart Life app account to your Tuya Cloud Project.")
    print("   Go to Tuya IoT -> Cloud -> Projects -> Devices -> Link Tuya App Account and scan the QR code from your Smart Life app.")
    print("2. The Device ID is incorrect.")
