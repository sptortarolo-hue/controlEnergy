# Guía de Publicación (Deploy) - Smart Life Home Energy

La aplicación ha sido preparada para ser subida a un servidor web (VPS, Render, Railway, etc.).

### Cambios realizados para producción:
1. **Frontend Integrado**: Flask sirve directamente `index.html`, `dashboard.html` y `login.html`.
2. **Seguridad**: Se requiere contraseña para acceder. El token de sesión se maneja automáticamente.
3. **Servidor de Producción**: Se incluye `gunicorn` para Linux y `waitress` para Windows.

---

### Despliegue en Render.com (Recomendado)
1. Sube tu código a GitHub.
2. Crea un **Web Service** en Render.
3. Configura las siguientes **Environment Variables**:
   - `TUYA_ACCESS_ID` = (Tu Access ID de Tuya)
   - `TUYA_ACCESS_SECRET` = (Tu Secret de Tuya)
   - `TUYA_ENDPOINT` = `https://openapi.tuyaus.com`
   - `AUTH_PASSWORD` = (La contraseña que quieras para entrar a tu app)
   - `JWT_SECRET` = (Una clave aleatoria para la seguridad interna)
4. **Build Command**: `pip install -r requirements.txt`
5. **Start Command**: `gunicorn --bind 0.0.0.0:$PORT backend.app:app`

### Persistencia de Datos
En el plan gratuito de Render, el archivo `smartlife.db` se reinicia con cada despliegue. Si quieres guardar el historial permanentemente, deberás añadir un **Disk** (pago) en Render y mapear el archivo `.db` allí, o usar una base de datos externa.

¡Tu app ya está segura y lista para la web!
