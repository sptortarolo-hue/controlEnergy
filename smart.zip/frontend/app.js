const API_URL = '/api';

// ==========================================
// PREFERENCES (LocalStorage)
// ==========================================
const PREFS_KEY = 'smartlife_prefs';

const METRIC_DEFINITIONS = [
    { key: 'voltage', label: 'Voltaje', icon: 'fa-bolt', codes: ['phase_a'] },
    { key: 'current_a', label: 'Corriente (A)', icon: 'fa-wave-square', codes: ['phase_a'] },
    { key: 'power', label: 'Potencia (W)', icon: 'fa-plug', codes: ['phase_a'] },
    { key: 'power_factor', label: 'Factor de Potencia', icon: 'fa-percent', codes: ['phase_a'] },
    { key: 'energy', label: 'Energía (kWh)', icon: 'fa-chart-line', codes: ['total_forward_energy'] },
    { key: 'temp', label: 'Temperatura', icon: 'fa-temperature-half', codes: ['temp_current'] },
    { key: 'battery', label: 'Batería', icon: 'fa-battery-half', codes: ['battery_percentage'] },
    { key: 'leakage', label: 'Corriente de Fuga', icon: 'fa-triangle-exclamation', codes: ['leakage_current'] },
    { key: 'switch2', label: 'Estado Canal 2', icon: 'fa-toggle-on', codes: ['switch_2'] },
    { key: 'door', label: 'Estado Puerta', icon: 'fa-door-open', codes: ['doorcontact_state'] },
];

function loadPrefs() {
    try { return JSON.parse(localStorage.getItem(PREFS_KEY)) || {}; }
    catch { return {}; }
}

function savePrefs(prefs) {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
}

function getDevicePrefs(deviceId) {
    const prefs = loadPrefs();
    if (!prefs[deviceId]) prefs[deviceId] = { hidden: false, hiddenMetrics: [] };
    return prefs[deviceId];
}

function setDevicePrefs(deviceId, updates) {
    const prefs = loadPrefs();
    prefs[deviceId] = { ...getDevicePrefs(deviceId), ...updates };
    savePrefs(prefs);
}

// ==========================================
// DEVICE CAPABILITY DETECTION
// ==========================================

// Categories that are pure switches: no advanced metrics, no dashboard
const SWITCH_CATEGORIES = ['kg', 'tdq', 'qjdcz', 'wxkg'];

// Advanced metric status codes (anything beyond basic switch control)
const ADVANCED_CODES = [
    'phase_a', 'total_forward_energy', 'temp_current',
    'battery_percentage', 'leakage_current', 'doorcontact_state'
];

/**
 * Returns true if the device has advanced metrics worth showing
 * (anything beyond simple on/off switching).
 */
function deviceHasAdvancedMetrics(device) {
    if (SWITCH_CATEGORIES.includes(device.category)) return false;
    // Check _metrics from backend
    const m = device._metrics || {};
    if (Object.keys(m).length > 0) return true;
    // Check status codes
    return (device.status || []).some(s => ADVANCED_CODES.includes(s.code));
}

/**
 * Returns true if the device supports the dashboard
 * (must have logged/loggable numeric metrics).
 */
function deviceSupportsDashboard(device) {
    if (SWITCH_CATEGORIES.includes(device.category)) return false;
    // Only devices with electrical measurements or battery get a dashboard
    const hasPower = !!(device._metrics && (
        device._metrics.voltage !== undefined ||
        device._metrics.power_w !== undefined ||
        device._metrics.energy_kwh !== undefined
    ));
    const hasBattery = (device.status || []).some(s => s.code === 'battery_percentage');
    return hasPower || hasBattery;
}

// ==========================================
// GLOBAL STATE
// ==========================================
let allDevices = [];
let currentModalDeviceId = null;

// ==========================================
// INIT
// ==========================================
const POLL_INTERVAL_MS = 30000; // 30 seconds
let pollingTimer = null;

function getAuthHeader() {
    const token = localStorage.getItem('smartlife_token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
}

function checkAuth() {
    if (!localStorage.getItem('smartlife_token')) {
        window.location.href = '/login.html';
        return false;
    }
    return true;
}

document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) return;
    checkApiStatus();
    fetchDevices();
    setupModals();
    // Start real-time polling
    pollingTimer = setInterval(pollDevices, POLL_INTERVAL_MS);
});

// ==========================================
// API STATUS
// ==========================================
async function checkApiStatus() {
    const statusDot = document.querySelector('.dot');
    const statusText = document.querySelector('.status-text');
    try {
        const response = await fetch(`${API_URL}/status`, { headers: getAuthHeader() });
        if (response.status === 401) { window.location.href = '/login.html'; return; }
        const data = await response.json();
        if (response.ok && data.status === 'ok') {
            statusDot.className = 'dot connected';
            statusText.textContent = 'Conectado';
        } else {
            statusDot.className = 'dot disconnected';
            statusText.textContent = 'Error de Configuración';
            showError(data.message || 'Error en el backend');
        }
    } catch {
        statusDot.className = 'dot disconnected';
        statusText.textContent = 'Desconectado';
        showError('No se pudo conectar al servidor local (Flask). Asegúrate de que app.py esté corriendo.');
    }
}

// ==========================================
// FETCH DEVICES (initial full render)
// ==========================================
async function fetchDevices() {
    const grid = document.getElementById('device-grid');
    try {
        const response = await fetch(`${API_URL}/devices`, { headers: getAuthHeader() });
        if (response.status === 401) { window.location.href = '/login.html'; return; }
        const data = await response.json();
        if (response.ok && data.status === 'success') {
            allDevices = data.devices;
            renderDevices(allDevices);
            hideError();
        } else {
            grid.innerHTML = '';
            showError(data.message || 'Error al obtener dispositivos.');
        }
    } catch (error) {
        console.error('Fetch devices error:', error);
    }
}

// ==========================================
// POLL DEVICES (smart in-place update)
// ==========================================
async function pollDevices() {
    try {
        const response = await fetch(`${API_URL}/devices`, { headers: getAuthHeader() });
        if (response.status === 401) { window.location.href = '/login.html'; return; }
        const data = await response.json();
        if (!response.ok || data.status !== 'success') return;

        // Update global state
        allDevices = data.devices;

        // If a modal is open, update the modal device data too
        if (currentModalDeviceId) {
            const updated = allDevices.find(d => d.id === currentModalDeviceId);
            if (updated) {
                // Silently update the device reference inside the modal
                // (metrics already showed, no full re-render needed)
            }
        }

        // Update each visible card in-place without re-rendering the whole grid
        allDevices.forEach(device => {
            const card = document.querySelector(`.device-card[data-device-id="${device.id}"]`);
            if (!card) return; // card is hidden or not rendered

            const m = device._metrics || {};
            const prefs = getDevicePrefs(device.id);
            const hiddenMetrics = prefs.hiddenMetrics || [];

            // --- Update switch status ---
            const validSwitchCodes = ['switch', 'switch_1', 'switch_led'];
            let switchStatus = null;
            for (const code of validSwitchCodes) {
                switchStatus = (device.status || []).find(s => s.code === code);
                if (switchStatus) break;
            }
            if (!switchStatus) {
                switchStatus = (device.status || []).find(s =>
                    s.code.includes('switch') && typeof s.value === 'boolean' && !s.code.includes('prepayment')
                );
            }
            const isOn = switchStatus ? switchStatus.value : false;

            const toggle = card.querySelector('.device-toggle');
            const statusText = card.querySelector('.device-status');

            // Only update if the value actually changed (avoid flickering)
            if (toggle && toggle.checked !== isOn) {
                toggle.checked = isOn;
                statusText.textContent = isOn ? 'Encendido' : 'Apagado';
                if (isOn) card.classList.add('active');
                else card.classList.remove('active');
            }

            // --- Update metric badges in-place ---
            const detailsContainer = card.querySelector('.device-details');
            if (detailsContainer) {
                const newHtml = buildMetricBadges(device, hiddenMetrics);
                if (newHtml) {
                    detailsContainer.innerHTML = newHtml;
                    detailsContainer.style.display = 'flex';
                } else {
                    detailsContainer.style.display = 'none';
                }
            }
        });

        // Update the last-refreshed timestamp in the header
        updateRefreshTimestamp();
    } catch (e) {
        console.warn('Poll failed:', e);
    }
}

function updateRefreshTimestamp() {
    let el = document.getElementById('last-refresh');
    if (!el) {
        const header = document.querySelector('.header-right');
        if (!header) return;
        el = document.createElement('span');
        el.id = 'last-refresh';
        el.style.cssText = 'font-size:0.72rem;color:var(--text-secondary);white-space:nowrap;';
        header.prepend(el);
    }
    const now = new Date();
    el.textContent = `↻ ${now.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
}

// ==========================================
// RENDER DEVICES
// ==========================================
function renderDevices(devices) {
    const grid = document.getElementById('device-grid');
    grid.innerHTML = '';

    if (!devices || devices.length === 0) {
        grid.innerHTML = '<p class="device-status">No se encontraron dispositivos vinculados.</p>';
        return;
    }

    devices.forEach(device => {
        const prefs = getDevicePrefs(device.id);
        if (prefs.hidden) return;

        const validSwitchCodes = ['switch', 'switch_1', 'switch_led'];
        let switchStatus = null;
        for (const code of validSwitchCodes) {
            switchStatus = (device.status || []).find(s => s.code === code);
            if (switchStatus) break;
        }
        if (!switchStatus) {
            switchStatus = (device.status || []).find(s =>
                s.code.includes('switch') && typeof s.value === 'boolean' && !s.code.includes('prepayment')
            );
        }
        const isOn = switchStatus ? switchStatus.value : false;

        const template = document.getElementById('device-card-template');
        const clone = template.content.cloneNode(true);
        const card = clone.querySelector('.device-card');

        card.dataset.deviceId = device.id;
        if (isOn) card.classList.add('active');

        const icon = clone.querySelector('.device-icon');
        const catIcons = { cz: 'fa-plug', dj: 'fa-lightbulb', mcs: 'fa-door-open', dlq: 'fa-bolt' };
        icon.className = `fa-solid ${catIcons[device.category] || 'fa-microchip'} device-icon`;

        clone.querySelector('.device-name').textContent = device.name;
        clone.querySelector('.device-status').textContent = isOn ? 'Encendido' : 'Apagado';

        // Set dashboard link — only for devices with advanced metrics
        const dashBtn = clone.querySelector('.card-dashboard-btn');
        if (dashBtn) {
            if (deviceSupportsDashboard(device)) {
                dashBtn.href = `dashboard.html?device_id=${device.id}&name=${encodeURIComponent(device.name)}`;
                dashBtn.addEventListener('click', e => e.stopPropagation());
            } else {
                dashBtn.style.display = 'none';
            }
        }

        const toggle = clone.querySelector('.device-toggle');
        toggle.checked = isOn;
        toggle.addEventListener('click', e => e.stopPropagation());
        toggle.addEventListener('change', (e) => {
            e.stopPropagation();
            const newValue = e.target.checked;
            const switchCode = switchStatus ? switchStatus.code : 'switch_1';
            toggleDevice(device.id, switchCode, newValue, card);
        });

        // Click on card → open modal (now for all devices, to allow hiding)
        card.addEventListener('click', (e) => {
            if (e.target.closest('.toggle-switch')) return;
            if (e.target.closest('.card-dashboard-btn')) return;
            openDeviceModal(device);
        });

        // Show pointer for all cards as they now all open the modal
        card.style.cursor = 'pointer';

        // Build advanced metrics badges (only if device has them)
        const detailsContainer = clone.querySelector('.device-details');
        if (deviceHasAdvancedMetrics(device)) {
            const hiddenMetrics = prefs.hiddenMetrics || [];
            const detailsHtml = buildMetricBadges(device, hiddenMetrics);
            if (detailsHtml) {
                detailsContainer.innerHTML = detailsHtml;
                detailsContainer.style.display = 'flex';
            }
        }

        grid.appendChild(clone);
    });
}

// ==========================================
// BUILD METRIC BADGES
// ==========================================
function buildMetricBadges(device, hiddenMetrics = []) {
    let html = '';
    const m = device._metrics || {};

    if (m.voltage !== undefined && !hiddenMetrics.includes('voltage'))
        html += `<span class="detail-badge"><i class="fa-solid fa-bolt"></i> ${m.voltage.toFixed(1)} V</span>`;

    if (m.current_a !== undefined && !hiddenMetrics.includes('current_a'))
        html += `<span class="detail-badge"><i class="fa-solid fa-wave-square"></i> ${m.current_a.toFixed(3)} A</span>`;

    if (m.power_w !== undefined && !hiddenMetrics.includes('power'))
        html += `<span class="detail-badge"><i class="fa-solid fa-plug"></i> ${m.power_w} W</span>`;

    if (m.power_factor !== undefined && m.power_factor > 0 && !hiddenMetrics.includes('power_factor'))
        html += `<span class="detail-badge"><i class="fa-solid fa-percent"></i> FP: ${m.power_factor}%</span>`;

    if (m.energy_kwh !== undefined && !hiddenMetrics.includes('energy'))
        html += `<span class="detail-badge"><i class="fa-solid fa-chart-line"></i> ${m.energy_kwh.toFixed(2)} kWh</span>`;

    if (m.temperature !== undefined && !hiddenMetrics.includes('temp'))
        html += `<span class="detail-badge"><i class="fa-solid fa-temperature-half"></i> ${m.temperature}°C</span>`;

    const batteryStatus = (device.status || []).find(s => s.code === 'battery_percentage');
    if (batteryStatus && !hiddenMetrics.includes('battery')) {
        const batColor = batteryStatus.value > 20 ? '#4caf50' : '#f44336';
        html += `<span class="detail-badge" style="color:${batColor}"><i class="fa-solid fa-battery-half"></i> ${batteryStatus.value}%</span>`;
    }

    const leakStatus = (device.status || []).find(s => s.code === 'leakage_current');
    if (leakStatus && leakStatus.value > 0 && !hiddenMetrics.includes('leakage'))
        html += `<span class="detail-badge" style="color:#f59e0b"><i class="fa-solid fa-triangle-exclamation"></i> Fuga: ${leakStatus.value} mA</span>`;

    return html;
}

// ==========================================
// TOGGLE DEVICE ON/OFF
// ==========================================
async function toggleDevice(deviceId, code, value, cardElement) {
    const statusText = cardElement.querySelector('.device-status');
    const toggle = cardElement.querySelector('.device-toggle');
    const originalValue = !value;

    statusText.textContent = value ? 'Encendido' : 'Apagado';
    if (value) cardElement.classList.add('active');
    else cardElement.classList.remove('active');

    try {
        const response = await fetch(`${API_URL}/devices/${deviceId}/commands`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                ...getAuthHeader()
            },
            body: JSON.stringify({ commands: [{ code, value }] })
        });
        if (response.status === 401) { window.location.href = '/login.html'; return; }
        const data = await response.json();
        if (!response.ok || data.status !== 'success') throw new Error(data.message);
    } catch (error) {
        console.error('Toggle error:', error);
        toggle.checked = originalValue;
        statusText.textContent = originalValue ? 'Encendido' : 'Apagado';
        if (originalValue) cardElement.classList.add('active');
        else cardElement.classList.remove('active');
        alert('Hubo un error al controlar el dispositivo.');
    }
}

// ==========================================
// MODAL: DEVICE SETTINGS
// ==========================================
function openDeviceModal(device) {
    currentModalDeviceId = device.id;
    const modal = document.getElementById('device-modal');
    document.getElementById('modal-device-name').textContent = device.name;

    const prefs = getDevicePrefs(device.id);
    const hiddenMetrics = prefs.hiddenMetrics || [];
    const container = document.getElementById('metric-toggles-container');
    const subtitle = modal.querySelector('.modal-subtitle');
    container.innerHTML = '';

    // Only show metrics section if device has advanced metrics
    const hasAdvanced = deviceHasAdvancedMetrics(device);
    const topDivider = container.nextElementSibling; // The first hr

    if (!hasAdvanced) {
        if (subtitle) subtitle.style.display = 'none';
        container.style.display = 'none';
        if (topDivider && topDivider.classList.contains('modal-divider')) {
            topDivider.style.display = 'none';
        }
    } else {
        if (subtitle) subtitle.style.display = 'block';
        container.style.display = 'grid'; // or block/flex depending on css

        let hasAny = false;
        METRIC_DEFINITIONS.forEach(metric => {
            const hasMetric =
                metric.codes.some(code => (device.status || []).find(s => s.code === code)) ||
                (metric.codes.includes('phase_a') && device._metrics && Object.keys(device._metrics).length > 0);

            if (!hasMetric) return;
            hasAny = true;

            const isVisible = !hiddenMetrics.includes(metric.key);
            const item = document.createElement('div');
            item.className = 'metric-toggle-item';
            item.innerHTML = `
                <label class="metric-toggle-label" for="metric-${metric.key}">
                    <i class="fa-solid ${metric.icon}"></i> ${metric.label}
                </label>
                <label class="toggle-switch">
                    <input type="checkbox" id="metric-${metric.key}" data-metric="${metric.key}" ${isVisible ? 'checked' : ''}>
                    <span class="slider round"></span>
                </label>
            `;
            item.querySelector('input').addEventListener('change', (e) => {
                const key = e.target.dataset.metric;
                const p = getDevicePrefs(currentModalDeviceId);
                let hidden = p.hiddenMetrics || [];
                if (!e.target.checked) { if (!hidden.includes(key)) hidden.push(key); }
                else { hidden = hidden.filter(k => k !== key); }
                setDevicePrefs(currentModalDeviceId, { hiddenMetrics: hidden });
                renderDevices(allDevices);
            });
            container.appendChild(item);
        });

        if (!hasAny) {
            container.innerHTML = '<p class="text-muted">Este dispositivo no tiene métricas adicionales.</p>';
        }
    }

    // Dashboard button - only show if supported
    const dashBtn = document.getElementById('open-dashboard-btn');
    const dashDivider = dashBtn ? dashBtn.previousElementSibling : null;
    
    if (dashBtn) {
        if (deviceSupportsDashboard(device)) {
            dashBtn.style.display = 'flex';
            if (dashDivider) dashDivider.style.display = 'block';
            dashBtn.onclick = () => {
                window.open(`dashboard.html?device_id=${device.id}&name=${encodeURIComponent(device.name)}`, '_blank');
            };
        } else {
            dashBtn.style.display = 'none';
            if (dashDivider) dashDivider.style.display = 'none';
        }
    }

    // Hide device button
    document.getElementById('hide-device-btn').onclick = () => {
        setDevicePrefs(device.id, { hidden: true });
        closeAllModals();
        renderDevices(allDevices);
    };

    modal.style.display = 'flex';
}

// ==========================================
// MODAL: GLOBAL SETTINGS (Hidden Devices)
// ==========================================
function openSettingsModal() {
    const modal = document.getElementById('settings-modal');
    const list = document.getElementById('hidden-devices-list');
    const emptyMsg = document.getElementById('no-hidden-devices-msg');

    list.innerHTML = '';
    const hidden = allDevices.filter(d => getDevicePrefs(d.id).hidden);

    if (hidden.length === 0) {
        emptyMsg.style.display = 'block';
    } else {
        emptyMsg.style.display = 'none';
        hidden.forEach(device => {
            const item = document.createElement('div');
            item.className = 'hidden-device-item';
            item.innerHTML = `
                <span class="hidden-device-name">
                    <i class="fa-solid fa-eye-slash"></i> ${device.name}
                </span>
                <button class="success-btn show-device-btn" data-id="${device.id}">
                    <i class="fa-solid fa-eye"></i> Mostrar
                </button>
            `;
            item.querySelector('.show-device-btn').addEventListener('click', () => {
                setDevicePrefs(device.id, { hidden: false });
                renderDevices(allDevices);
                openSettingsModal();
            });
            list.appendChild(item);
        });
    }

    modal.style.display = 'flex';
}

// ==========================================
// MODAL SETUP
// ==========================================
function setupModals() {
    document.querySelectorAll('.close-modal-btn').forEach(btn => {
        btn.addEventListener('click', closeAllModals);
    });
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeAllModals();
        });
    });
    document.getElementById('global-settings-btn').addEventListener('click', openSettingsModal);
    document.getElementById('logout-btn').addEventListener('click', () => {
        localStorage.removeItem('smartlife_token');
        window.location.href = '/login.html';
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeAllModals();
    });
}

function closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
    currentModalDeviceId = null;
}

// ==========================================
// ERROR HELPERS
// ==========================================
function showError(message) {
    const errorContainer = document.getElementById('error-message');
    document.getElementById('error-text').textContent = message;
    errorContainer.style.display = 'flex';
}

function hideError() {
    document.getElementById('error-message').style.display = 'none';
}
