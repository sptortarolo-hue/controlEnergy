const API_URL = '/api';

// Get device ID and name from URL params
const urlParams = new URLSearchParams(window.location.search);
const DEVICE_ID = urlParams.get('device_id') || '';
const DEVICE_NAME = urlParams.get('name') || 'Dispositivo';

let chartPower = null;
let chartDaily = null;

// ==========================================
// CHART.JS DEFAULTS
// ==========================================
Chart.defaults.color = '#94a3b8';
Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';
Chart.defaults.font.family = 'Inter';

function getAuthHeader() {
    const token = localStorage.getItem('smartlife_token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
}

function checkAuth() {
    if (!localStorage.getItem('smartlife_token')) {
        window.location.href = '/login.html';
        return false;
    }
    return true;
}

// ==========================================
// INIT
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) return;
    document.getElementById('dashboard-device-name').textContent = DEVICE_NAME;

    if (!DEVICE_ID) {
        document.getElementById('no-data-msg').style.display = 'block';
        return;
    }

    // Set default date range: last 7 days
    const today = new Date();
    const weekAgo = new Date();
    weekAgo.setDate(today.getDate() - 6);
    document.getElementById('date-to').value   = today.toISOString().split('T')[0];
    document.getElementById('date-from').value = weekAgo.toISOString().split('T')[0];

    loadDashboard();

    document.getElementById('refresh-btn').addEventListener('click', loadDashboard);
    document.getElementById('snapshot-btn').addEventListener('click', triggerSnapshot);
    document.getElementById('analyze-btn').addEventListener('click', runAnalysis);
});

// ==========================================
// LOAD ALL DASHBOARD DATA
// ==========================================
async function loadDashboard() {
    const btn = document.getElementById('refresh-btn');
    btn.querySelector('i').classList.add('fa-spin');

    await Promise.all([
        loadKpis(),
        loadPowerChart(),
        loadDailyChart(),
        loadRecentRecords(),
    ]);

    btn.querySelector('i').classList.remove('fa-spin');
}

// ==========================================
// LOAD LIVE KPIs (from /api/devices)
// ==========================================
async function loadKpis() {
    try {
        const res = await fetch(`${API_URL}/devices`, { headers: getAuthHeader() });
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();
        if (!data.devices) return;

        const device = data.devices.find(d => d.id === DEVICE_ID);
        if (!device) return;

        const m = device._metrics || {};
        setKpi('kpi-voltage', m.voltage, 'V', 1);
        setKpi('kpi-current', m.current_a, 'A', 3);
        setKpi('kpi-power', m.power_w, 'W', 0);
        setKpi('kpi-energy', m.energy_kwh, 'kWh', 2);
        setKpi('kpi-pf', m.power_factor, '%', 0);
        setKpi('kpi-temp', m.temperature, '°C', 0);
    } catch (e) {
        console.error('loadKpis error', e);
    }
}

function setKpi(id, value, unit, decimals) {
    const el = document.getElementById(id);
    if (el && value !== undefined && value !== null) {
        el.textContent = `${Number(value).toFixed(decimals)} ${unit}`;
    }
}

// ==========================================
// HOURLY POWER CHART (last 24h)
// ==========================================
async function loadPowerChart() {
    try {
        const res = await fetch(`${API_URL}/history/hourly?device_id=${DEVICE_ID}&days=1`, { headers: getAuthHeader() });
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();
        const rows = data.data || [];

        const labels = rows.map(r => {
            const d = new Date(r.timestamp + 'Z');
            return d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
        });
        const powers = rows.map(r => r.power_w ?? null);

        const ctx = document.getElementById('chart-power').getContext('2d');

        if (chartPower) chartPower.destroy();
        chartPower = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Potencia (W)',
                    data: powers,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.1)',
                    borderWidth: 2,
                    pointRadius: 3,
                    pointBackgroundColor: '#3b82f6',
                    fill: true,
                    tension: 0.4,
                    spanGaps: true,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.04)' } },
                    y: { grid: { color: 'rgba(255,255,255,0.04)' }, beginAtZero: true }
                }
            }
        });

        if (rows.length === 0) showNoData();
    } catch (e) {
        console.error('loadPowerChart error', e);
    }
}

// ==========================================
// DAILY ENERGY CHART (last 7 days)
// ==========================================
async function loadDailyChart() {
    try {
        const res = await fetch(`${API_URL}/history/daily?device_id=${DEVICE_ID}&days=7`, { headers: getAuthHeader() });
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();
        const rows = data.data || [];

        const labels = rows.map(r => {
            const [y, m, d] = r.day.split('-');
            return `${d}/${m}`;
        });
        const values = rows.map(r => r.energy_consumed_kwh);

        const ctx = document.getElementById('chart-daily').getContext('2d');

        if (chartDaily) chartDaily.destroy();
        chartDaily = new Chart(ctx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Consumo (kWh)',
                    data: values,
                    backgroundColor: 'rgba(16,185,129,0.3)',
                    borderColor: '#10b981',
                    borderWidth: 1.5,
                    borderRadius: 6,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { color: 'rgba(255,255,255,0.04)' } },
                    y: { grid: { color: 'rgba(255,255,255,0.04)' }, beginAtZero: true }
                }
            }
        });
    } catch (e) {
        console.error('loadDailyChart error', e);
    }
}

// ==========================================
// RECENT RECORDS TABLE
// ==========================================
async function loadRecentRecords() {
    try {
        const res = await fetch(`${API_URL}/history/hourly?device_id=${DEVICE_ID}&days=7`, { headers: getAuthHeader() });
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();
        const rows = (data.data || []).reverse().slice(0, 20);

        const tbody = document.getElementById('records-body');
        if (rows.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-muted" style="text-align:center;padding:1.5rem;">Sin registros todavía</td></tr>';
            showNoData();
            return;
        }

        tbody.innerHTML = rows.map(r => {
            const dt = new Date(r.timestamp + 'Z');
            const formatted = dt.toLocaleString('es-AR', {
                day: '2-digit', month: '2-digit', year: 'numeric',
                hour: '2-digit', minute: '2-digit'
            });
            const stateBadge = r.switch_state === 1
                ? '<span class="badge-on">Encendido</span>'
                : '<span class="badge-off">Apagado</span>';
            return `
                <tr>
                    <td>${formatted}</td>
                    <td>${r.voltage != null ? r.voltage.toFixed(1) : '—'}</td>
                    <td>${r.current_a != null ? r.current_a.toFixed(3) : '—'}</td>
                    <td>${r.power_w != null ? r.power_w : '—'}</td>
                    <td>${r.power_factor != null ? r.power_factor : '—'}</td>
                    <td>${r.energy_kwh != null ? r.energy_kwh.toFixed(2) : '—'}</td>
                    <td>${r.temperature != null ? r.temperature : '—'}</td>
                    <td>${stateBadge}</td>
                </tr>
            `;
        }).join('');
    } catch (e) {
        console.error('loadRecentRecords error', e);
    }
}

// ==========================================
// MANUAL SNAPSHOT
// ==========================================
async function triggerSnapshot() {
    const btn = document.getElementById('snapshot-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Guardando...';
    try {
        const res = await fetch(`${API_URL}/history/snapshot`, { 
            method: 'POST',
            headers: getAuthHeader()
        });
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();
        if (data.status === 'success') {
            btn.innerHTML = '<i class="fa-solid fa-check"></i> ¡Guardado!';
            setTimeout(() => {
                btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Guardar lectura';
                btn.disabled = false;
                loadDashboard();
            }, 1500);
        }
    } catch (e) {
        btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Guardar lectura';
        btn.disabled = false;
    }
}

function showNoData() {
    document.getElementById('no-data-msg').style.display = 'block';
}

// ==========================================
// STATS ANALYSIS (Date Range)
// ==========================================
let chartStatsHourly = null;
let chartStatsDaily  = null;

async function runAnalysis() {
    const dateFrom = document.getElementById('date-from').value;
    const dateTo   = document.getElementById('date-to').value;

    if (!dateFrom || !dateTo) {
        alert('Por favor selecciona ambas fechas.');
        return;
    }
    if (dateFrom > dateTo) {
        alert('La fecha de inicio debe ser anterior o igual a la fecha de fin.');
        return;
    }

    const btn = document.getElementById('analyze-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analizando...';

    try {
        const res = await fetch(
            `${API_URL}/history/stats?device_id=${DEVICE_ID}&date_from=${dateFrom}&date_to=${dateTo}`,
            { headers: getAuthHeader() }
        );
        if (res.status === 401) { window.location.href = '/login.html'; return; }
        const data = await res.json();

        if (data.status !== 'success' || !data.summary) {
            document.getElementById('stats-result').style.display = 'none';
            document.getElementById('stats-empty').style.display  = 'flex';
            return;
        }

        const s = data.summary;

        if (s.total_readings === 0) {
            document.getElementById('stats-result').style.display = 'none';
            document.getElementById('stats-empty').style.display  = 'flex';
            return;
        }

        document.getElementById('stats-empty').style.display  = 'none';
        document.getElementById('stats-result').style.display = 'block';

        // --- Fill KPI cards ---
        document.getElementById('stat-energy').textContent    = `${s.energy_consumed_kwh} kWh`;
        document.getElementById('stat-avg-power').textContent = `${s.avg_power_w} W`;
        document.getElementById('stat-peak-power').textContent= `${s.peak_power_w ?? '—'} W`;
        document.getElementById('stat-avg-current').textContent = `${s.avg_current} A`;
        document.getElementById('stat-avg-temp').textContent  = `${s.avg_temp} °C`;

        // Peak hour badge
        const ph = s.peak_hour;
        if (ph !== null && ph !== undefined) {
            document.getElementById('stat-peak-hour').textContent =
                `${String(ph).padStart(2,'0')}:00 – ${String(ph + 1).padStart(2,'0')}:00`;
        } else {
            document.getElementById('stat-peak-hour').textContent = '—';
        }

        // --- Hourly chart (all 24 hours, fill gaps with null) ---
        const hourlyMap = {};
        data.hourly.forEach(r => { hourlyMap[r.hour] = r.avg_power; });
        const hourLabels = Array.from({length: 24}, (_, i) => `${String(i).padStart(2,'0')}h`);
        const hourValues = Array.from({length: 24}, (_, i) => hourlyMap[i] ?? null);
        // Highlight peak hour bar
        const hourColors = hourLabels.map((_, i) =>
            i === ph ? 'rgba(245, 158, 11, 0.7)' : 'rgba(59,130,246,0.4)'
        );
        const hourBorders = hourLabels.map((_, i) =>
            i === ph ? '#f59e0b' : '#3b82f6'
        );

        if (chartStatsHourly) chartStatsHourly.destroy();
        chartStatsHourly = new Chart(
            document.getElementById('chart-stats-hourly').getContext('2d'),
            {
                type: 'bar',
                data: {
                    labels: hourLabels,
                    datasets: [{
                        label: 'Potencia Prom. (W)',
                        data: hourValues,
                        backgroundColor: hourColors,
                        borderColor: hourBorders,
                        borderWidth: 1.5,
                        borderRadius: 4,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                title: (items) => `Hora: ${items[0].label}`,
                                label: (item) => item.raw !== null ? `${item.raw.toFixed(1)} W` : 'Sin datos'
                            }
                        }
                    },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.04)' } },
                        y: { grid: { color: 'rgba(255,255,255,0.04)' }, beginAtZero: true }
                    }
                }
            }
        );

        // --- Daily chart ---
        const dailyLabels = data.daily.map(r => {
            const [y, m, d] = r.day.split('-');
            return `${d}/${m}`;
        });
        const dailyValues = data.daily.map(r => r.energy_consumed_kwh);

        if (chartStatsDaily) chartStatsDaily.destroy();
        chartStatsDaily = new Chart(
            document.getElementById('chart-stats-daily').getContext('2d'),
            {
                type: 'bar',
                data: {
                    labels: dailyLabels,
                    datasets: [{
                        label: 'Energía (kWh)',
                        data: dailyValues,
                        backgroundColor: 'rgba(16,185,129,0.35)',
                        borderColor: '#10b981',
                        borderWidth: 1.5,
                        borderRadius: 6,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { color: 'rgba(255,255,255,0.04)' } },
                        y: { grid: { color: 'rgba(255,255,255,0.04)' }, beginAtZero: true }
                    }
                }
            }
        );

    } catch (e) {
        console.error('runAnalysis error', e);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-chart-pie"></i> Analizar';
    }
}
